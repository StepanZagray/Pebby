"""Deterministic CPU learning laboratory with explicit optimization phases."""

from __future__ import annotations

from collections import OrderedDict
from contextlib import contextmanager
from typing import Literal

import numpy as np
import torch
from pydantic import BaseModel, Field
from torch import nn

from .tracing import TraceRecorder, tensor_summary

# The map draws one edge per weight, so weight matrices must arrive whole rather than
# preview-truncated. The widest demo tensors are a 32x16 batch activation (512 values)
# and a 16x16 weight matrix (256), so 1024 leaves every live tensor complete.
MAX_PREVIEW_VALUES = 1024


class Configuration(BaseModel):
    dataset: Literal["moons", "spiral", "xor"] = "moons"
    width: Literal[4, 8, 16] = 8
    activation: Literal["Tanh", "ReLU"] = "Tanh"
    optimizer: Literal["Adam", "SGD"] = "Adam"
    learning_rate: float = Field(default=0.03, ge=0.0001, le=0.2, allow_inf_nan=False)
    seed: int = Field(default=42, ge=0, le=1_000_000)


@contextmanager
def evaluation(model):
    modes = {module: module.training for module in model.modules()}
    model.eval()
    try:
        yield
    finally:
        for module, mode in modes.items():
            module.training = mode


def make_dataset(kind: str, seed: int):
    rng = np.random.default_rng(seed)
    labels = np.repeat([0, 1], 200)
    angle = rng.uniform(0, np.pi, 400)
    if kind == "moons":
        x = np.column_stack([np.cos(angle), np.sin(angle)])
        x[200:, 0] = 1 - x[200:, 0]
        x[200:, 1] = 0.5 - x[200:, 1]
        x = (x + rng.normal(0, 0.10, x.shape) - [0.5, 0.25]) / 1.1
    elif kind == "spiral":
        radius = rng.uniform(0.1, 1.6, 400)
        angle = radius * 3.8 + labels * np.pi + rng.normal(0, 0.15, 400)
        x = np.column_stack([radius * np.sin(angle), radius * np.cos(angle)])
    else:
        x = rng.uniform(-1.5, 1.5, (400, 2))
        labels = (x[:, 0] * x[:, 1] > 0).astype(int)
    order = rng.permutation(len(x))
    return torch.tensor(x[order], dtype=torch.float32), torch.tensor(labels[order])


class Experiment:
    def __init__(self, config: Configuration | None = None):
        self.config = config or Configuration()
        self.x, self.y = make_dataset(self.config.dataset, self.config.seed)
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(self.config.seed)
            activation = getattr(nn, self.config.activation)
            self.model = nn.Sequential(
                OrderedDict(
                    [
                        ("hidden_1", nn.Linear(2, self.config.width)),
                        ("activation_1", activation()),
                        ("hidden_2", nn.Linear(self.config.width, self.config.width)),
                        ("activation_2", activation()),
                        ("output", nn.Linear(self.config.width, 2)),
                    ]
                )
            )
        self.optimizer = getattr(torch.optim, self.config.optimizer)(
            self.model.parameters(),
            lr=self.config.learning_rate,
        )
        self.generator = torch.Generator().manual_seed(self.config.seed + 1)
        self.order = torch.randperm(320, generator=self.generator)
        self.cursor = 0
        self.step = 0
        self.epoch = 0
        self.phase = "ready"
        self.recorder: TraceRecorder | None = None
        self.trace = None
        self.loss = None
        self.batch_loss = None
        self.batch = None
        self.deltas: dict = {}
        self.history: list[dict] = []
        self.probe = [0.6, 0.2]
        self._measure()

    def close(self):
        if self.recorder is not None:
            self.recorder.close()
        self.recorder = None
        self.loss = None

    def advance(self):
        if self.phase in ("ready", "update"):
            if self.cursor >= 320:
                self.order = torch.randperm(320, generator=self.generator)
                self.cursor = 0
                self.epoch += 1
            ids = self.order[self.cursor : self.cursor + 32]
            self.cursor += 32
            self.batch = {
                "indices": ids.tolist(),
                "first_input": self.x[ids[0]].tolist(),
                "first_target": self.y[ids[0]].item(),
                "size": len(ids),
            }
            self.model.train()
            self.optimizer.zero_grad(set_to_none=True)
            self.deltas = {}
            self.recorder = TraceRecorder(self.model, max_values=MAX_PREVIEW_VALUES)
            self.recorder.__enter__()
            try:
                logits = self.model(self.x[ids])
                self.loss = nn.functional.cross_entropy(logits, self.y[ids])
                self.batch_loss = self.loss.item()
                self.trace = self.recorder.snapshot()
            except Exception:
                self.close()
                raise
            self.phase = "forward"
        elif self.phase == "forward":
            self.loss.backward()
            self.trace = self.recorder.snapshot()
            self.recorder.close()
            self.phase = "backward"
        else:
            before = {name: p.detach().clone() for name, p in self.model.named_parameters()}
            self.optimizer.step()
            self.deltas = {
                name: tensor_summary(p.detach() - before[name], MAX_PREVIEW_VALUES)
                for name, p in self.model.named_parameters()
            }
            # Preserve forward activations / gradients from this batch; weights are post-update.
            self.trace = self.recorder.snapshot()
            self.close()
            self.step += 1
            self.phase = "update"
            self._measure()

    def train_batch(self):
        # Finish a pending batch before starting another, without skipping any phase.
        self.advance()
        while self.phase != "update":
            self.advance()

    def _measure(self):
        with evaluation(self.model), torch.no_grad():
            logits = self.model(self.x)
            self.history.append(
                {
                    "step": self.step,
                    "train_loss": nn.functional.cross_entropy(logits[:320], self.y[:320]).item(),
                    "validation_loss": nn.functional.cross_entropy(
                        logits[320:], self.y[320:]
                    ).item(),
                    "train_accuracy": (logits[:320].argmax(-1) == self.y[:320])
                    .float()
                    .mean()
                    .item(),
                    "validation_accuracy": (logits[320:].argmax(-1) == self.y[320:])
                    .float()
                    .mean()
                    .item(),
                }
            )
        self.history = self.history[-501:]

    def infer(self, point: list[float] | None = None):
        if point is not None:
            self.probe = point
        # Suspend the training recorder: evaluation calls must not pollute a pending batch.
        with self.suspend_recording():
            with evaluation(self.model):
                with (
                    TraceRecorder(self.model, max_values=MAX_PREVIEW_VALUES) as recorder,
                    torch.no_grad(),
                ):
                    logits = self.model(torch.tensor([self.probe], dtype=torch.float32))
                    probabilities = logits.softmax(-1)[0].tolist()
                    trace = recorder.snapshot()
                # This separate autograd query does not accumulate into parameter .grad.
                inputs = torch.tensor([self.probe], dtype=torch.float32, requires_grad=True)
                target = int(np.argmax(probabilities))
                probability = self.model(inputs).softmax(-1)[0, target]
                sensitivity = torch.autograd.grad(probability, inputs)[0][0].tolist()
            # Inference has no parameter gradients; don't leak gradients from the last batch.
            for parameter in trace["parameters"]:
                parameter["gradient"] = None
            return {
                "point": self.probe,
                "probabilities": probabilities,
                "prediction": target,
                "sensitivity": sensitivity,
                "trace": trace,
            }

    def state(self):
        # Boundary evaluation also must not enter a pending training recorder.
        with self.suspend_recording(), evaluation(self.model), torch.no_grad():
            axis = torch.linspace(-2, 2, 35)
            yy, xx = torch.meshgrid(axis, axis, indexing="ij")
            points = torch.stack([xx.flatten(), yy.flatten()], dim=1)
            boundary = self.model(points).softmax(-1)[:, 1].reshape(35, 35).tolist()
        return {
            "config": self.config.model_dump(),
            "phase": self.phase,
            "step": self.step,
            "epoch": self.epoch,
            "batch": self.batch,
            "batch_loss": self.batch_loss,
            "trace": self.trace,
            "deltas": self.deltas,
            "history": list(self.history),
            "metrics": self.history[-1],
            "inference": self.infer(),
            "dataset": [
                {
                    "x": p[0],
                    "y": p[1],
                    "label": label,
                    "split": "train" if i < 320 else "validation",
                }
                for i, (p, label) in enumerate(zip(self.x.tolist(), self.y.tolist()))
            ],
            "boundary": boundary,
            "parameter_count": sum(p.numel() for p in self.model.parameters()),
        }

    @contextmanager
    def suspend_recording(self):
        if self.recorder is None:
            yield
        else:
            with self.recorder.pause():
                yield
