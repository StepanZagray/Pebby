import {$, api, fmt} from './common.js';
import {initMap, update as updateMap, currentModel, currentSelection, selectUnit, selectEdge, fit, centerOn} from './mapview.js';
import {inspect} from './inspector.js';
import {boundary, prediction, lossChart} from './charts.js';
import {parseTrace} from './import.js';

let state, mode = 'training', view = 'outputs', tensorKey;
let busy = false, running = false, timer, imported = null;
const explanations = {
  ready: 'Start with a forward pass. The model transforms a batch of 32 input points into two scores per point. The map previews your probe point.',
  forward: 'Forward pass complete. Each layer transformed the batch. Cross-entropy compares the final scores with the true classes and produces one loss. No weight has changed yet.',
  backward: 'Backward pass complete. PyTorch worked backward from the loss to compute gradients. Select a weight to see ∂loss/∂w for that single connection. Weights are still unchanged.',
  update: 'The optimizer has updated the weights using the gradients. Edge thickness now reflects the new weights; the activations and gradients on the map are the ones that produced this update.',
};

function currentTrace() { return imported || (mode === 'training' && state.trace ? state.trace : state.inference.trace); }

function controls() {
  for (const el of document.querySelectorAll('#config-form input, #config-form select, #reset, #step, #speed, #probe-form input, #probe-submit')) el.disabled = !state || busy || running || !!imported;
  $('#play').disabled = !state || !!imported || mode === 'inference' || (busy && !running);
  $('#step').disabled ||= mode === 'inference';
  $('#play').innerHTML = running ? '<span aria-hidden="true">❚❚</span> Pause' : '<span aria-hidden="true">▶</span> Run';
  $('#step').textContent = $('#speed').value === 'phase' ? 'Step phase' : 'Step batch';
  $('#trace-file').disabled = !state || busy || running;
  $('#return-live').disabled = busy;
  for (const m of ['training', 'inference']) {
    $(`#mode-${m}`).setAttribute('aria-pressed', mode === m);
    $(`#mode-${m}`).disabled = !state || busy || !!imported;
  }
  $('#map-stage').setAttribute('aria-busy', busy);
  for (const button of document.querySelectorAll('[data-inspect]')) button.disabled = !state;
}

function error(message) { $('#error').hidden = !message; $('#error').textContent = message || ''; $('#retry').hidden = !message || !!state; }

function renderInspector() {
  if (!state) return;
  inspect({
    model: currentModel(), selection: currentSelection(), trace: currentTrace(),
    view, tensorKey, mode, phase: state.phase,
    deltas: imported || mode === 'inference' ? {} : state.deltas,
    imported: !!imported,
  });
}

function render() {
  updateMap(currentTrace());
  renderInspector();
  const offline = !!imported;
  for (const selector of ['.phase-panel', '.phase-strip', '#phase-explanation', '.boundary-panel', '.learning-panel']) $(selector).hidden = offline;
  $('#return-live').hidden = !offline;
  $('#export').hidden = offline;
  $('#live-status').textContent = offline
    ? 'Imported snapshot · live training and predictions are hidden'
    : `${running ? 'RUNNING' : 'PAUSED'} / ${mode.toUpperCase()} · step ${state.step} · ${state.phase === 'ready' ? 'ready for first batch' : `last phase: ${state.phase}`} · seed ${state.config.seed}`;
  if (!offline) {
    for (const phase of ['forward', 'backward', 'update']) $(`#phase-${phase}`).classList.toggle('active', mode === 'training' && state.phase === phase);
    $('.phase-strip').hidden = mode === 'inference';
    $('#phase-explanation').textContent = mode === 'training' ? explanations[state.phase] : 'Inference uses the current weights to predict the class of one point. No optimizer step occurs. The two final scores become probabilities through softmax; input sensitivity is computed in a separate gradient query.';
    boundary(state); prediction(state.inference); lossChart(state.history);
    $('#train-loss').textContent = fmt(state.metrics.train_loss);
    $('#validation-loss').textContent = fmt(state.metrics.validation_loss);
    $('#accuracy').textContent = `${(state.metrics.validation_accuracy * 100).toFixed(1)}%`;
    $('#batch-loss').textContent = fmt(state.batch_loss);
    $('#step-count').textContent = `Step ${state.step}`;
    $('#probe-x').value = state.inference.point[0].toFixed(2);
    $('#probe-y').value = state.inference.point[1].toFixed(2);
    $('#drawer-summary').textContent = `step ${state.step} · loss ${fmt(state.metrics.train_loss, 3)} · accuracy ${(state.metrics.validation_accuracy * 100).toFixed(0)}%`;
  } else {
    $('#drawer-summary').textContent = 'hidden for imported traces';
  }
  controls();
}

function pause() { running = false; clearTimeout(timer); controls(); }

async function action(work) {
  if (busy) return;
  busy = true; error(''); controls();
  try { await work(); }
  catch (e) { pause(); error(e.message || 'Could not reach the Python server. Check that it is running, then retry.'); }
  finally { busy = false; if (state) render(); else controls(); }
}

async function tick() {
  if (!running) return;
  await action(async () => {
    const pace = $('#speed').value;
    state = await api('step', {kind: pace === 'phase' ? 'phase' : 'batch', count: pace === 'fast' ? 10 : 1});
  });
  if (running) timer = setTimeout(tick, $('#speed').value === 'phase' ? 1000 : 200);
}

$('#play').addEventListener('click', () => {
  if (running) { pause(); render(); }
  else { running = true; tick(); }
});
$('#step').addEventListener('click', () => action(async () => {
  state = await api('step', {kind: $('#speed').value === 'phase' ? 'phase' : 'batch'});
}));
$('#speed').addEventListener('change', controls);
for (const next of ['training', 'inference']) $(`#mode-${next}`).addEventListener('click', () => { pause(); mode = next; tensorKey = undefined; render(); });

$('#config-form').addEventListener('submit', event => {
  event.preventDefault(); pause();
  const data = Object.fromEntries(new FormData(event.currentTarget));
  for (const key of ['width', 'learning_rate', 'seed']) data[key] = Number(data[key]);
  action(async () => { state = await api('reset', data); view = 'outputs'; tensorKey = undefined; updateTabs(); });
});

function updateTabs() { for (const button of document.querySelectorAll('[data-inspect]')) button.setAttribute('aria-pressed', button.dataset.inspect === view); }
for (const button of document.querySelectorAll('[data-inspect]')) button.addEventListener('click', () => { view = button.dataset.inspect; tensorKey = undefined; updateTabs(); renderInspector(); });
$('#inspector-content').addEventListener('change', event => { if (event.target.id === 'tensor-select') { tensorKey = event.target.value; renderInspector(); $('#tensor-select')?.focus(); } });

// The inspector is the keyboard route to individual weights: every connection row and
// route endpoint selects the same thing a click on the map would.
$('#inspector-content').addEventListener('click', event => {
  const connection = event.target.closest('.connection');
  if (connection) { selectEdge(Number(connection.dataset.gap), Number(connection.dataset.from), Number(connection.dataset.to)); return; }
  const node = event.target.closest('.route-node');
  if (node) { selectUnit(Number(node.dataset.column), Number(node.dataset.unit)); centerOn(Number(node.dataset.column), Number(node.dataset.unit)); }
});

async function probe(x, y) {
  if (busy || running || imported) return;
  mode = 'inference';
  await action(async () => { state.inference = await api('infer', {x, y}); });
}
$('#probe-form').addEventListener('submit', event => { event.preventDefault(); probe(Number($('#probe-x').value), Number($('#probe-y').value)); });
$('#boundary').addEventListener('click', event => {
  const svg = $('#boundary-svg');
  if (!svg) return;
  const point = new DOMPoint(event.clientX, event.clientY).matrixTransform(svg.getScreenCTM().inverse());
  if (point.x < 32 || point.x > 282 || point.y < 8 || point.y > 258) return;
  probe(Number(((point.x - 32) / 250 * 4 - 2).toFixed(2)), Number((2 - (point.y - 8) / 250 * 4).toFixed(2)));
});

$('#trace-file').addEventListener('change', event => action(async () => {
  const file = event.target.files[0];
  if (!file) return;
  try {
    if (file.size > 5 * 1024 * 1024) throw new Error('Trace is larger than 5 MB. Reduce max_values or max_calls when recording.');
    imported = parseTrace(await file.text());
    tensorKey = undefined;
  } finally { event.target.value = ''; }
}));
$('#return-live').addEventListener('click', () => { imported = null; tensorKey = undefined; render(); fit(); });

$('#guide-open').addEventListener('click', () => $('#guide').showModal());
$('#guide-close').addEventListener('click', () => $('#guide').close());

// Docks collapse rather than overlap, so the map keeps every pixel it is given.
for (const [button, dock] of [['#rail-toggle', 'rail'], ['#inspector-toggle', 'inspector']]) {
  $(button).addEventListener('click', () => {
    const open = $(button).getAttribute('aria-expanded') !== 'true';
    $(button).setAttribute('aria-expanded', open);
    $('#app-shell').classList.toggle(`${dock}-collapsed`, !open);
  });
}

let chartWidth = 0;
new ResizeObserver(entries => {
  const width = entries[0].contentRect.width;
  if (state && !imported && width > 0 && width !== chartWidth) { chartWidth = width; lossChart(state.history); }
}).observe($('#loss-chart'));
$('#drawer').addEventListener('toggle', () => { if (state && !imported) { boundary(state); lossChart(state.history); } });

document.addEventListener('visibilitychange', () => { if (document.hidden) { pause(); if (state) render(); } });
window.addEventListener('pagehide', pause);

initMap(() => renderInspector());

async function connect() {
  await action(async () => {
    state = await api('state');
    for (const [key, value] of Object.entries(state.config)) $(`#config-form [name="${key}"]`).value = value;
  });
}
$('#retry').addEventListener('click', connect);
await connect();
