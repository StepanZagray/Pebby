export const $ = (selector) => document.querySelector(selector);
export const escape = (value) => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const fmt = (value, digits = 4) => value == null || !Number.isFinite(value) ? '—' : Math.abs(value) > 0 && Math.abs(value) < 0.0001 ? value.toExponential(2) : value.toFixed(digits);
export const first = object => Object.values(object || {})[0];
export const shape = tensor => tensor?.shape?.length ? `[${tensor.shape.join(' × ')}]` : 'scalar';
export function tint(value, max = 1) {
  if (value == null) return 'var(--input)';
  const rgb = value >= 0 ? '76,141,255' : '255,122,102';
  return `rgba(${rgb},${0.12 + 0.44 * Math.min(Math.abs(value) / (max || 1), 1)})`;
}
export async function api(path, body) {
  const response = await fetch(`/api/${path}`, body === undefined ? {} : {
    method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body),
  });
  if (!response.ok) {
    let message = `Request failed (${response.status})`;
    try { const data = await response.json(); message = typeof data.detail === 'string' ? data.detail : JSON.stringify(data.detail); } catch { /* Keep status message. */ }
    throw new Error(message);
  }
  return response.json();
}
