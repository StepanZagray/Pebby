import {$, fmt} from './common.js';

export function boundary(state) {
  const n = state.boundary.length, left = 32, top = 8, size = 250;
  const px = v => left + (v + 2) / 4 * size;
  const py = v => top + (2 - v) / 4 * size;
  // Diverging ramp: confident class 0 reads blue, class 1 violet, and the
  // undecided middle darkens so the boundary itself is visible.
  const mix = (a, b, t) => a.map((v, i) => Math.round(v + (b[i] - v) * t));
  const undecided = [21, 23, 28];
  let cells = '';
  state.boundary.forEach((row, y) => row.forEach((p, x) => {
    const color = (p < .5 ? mix([32, 54, 96], undecided, p * 2) : mix(undecided, [70, 53, 17], (p - .5) * 2)).join(',');
    // Grid predictions are sampled at endpoints; half-width edge cells align with points.
    const x0 = Math.max(0, (x - .5) / (n - 1));
    const x1 = Math.min(1, (x + .5) / (n - 1));
    const y0 = Math.max(0, (y - .5) / (n - 1));
    const y1 = Math.min(1, (y + .5) / (n - 1));
    cells += `<rect x="${left + x0 * size}" y="${top + (1 - y1) * size}" width="${(x1 - x0) * size + .2}" height="${(y1 - y0) * size + .2}" fill="rgb(${color})"/>`;
  }));
  const points = state.dataset.map(p => {
    const x = px(p.x), y = py(p.y), color = p.label ? 'var(--class-one)' : 'var(--signal)';
    const title = `<title>Class ${p.label} · ${p.split} · (${fmt(p.x, 2)}, ${fmt(p.y, 2)})</title>`;
    return p.split === 'train' ? `<circle cx="${x}" cy="${y}" r="2.5" fill="${color}" stroke="var(--bench)" stroke-width=".7">${title}</circle>` : `<path d="M${x},${y-3}l3,3 -3,3 -3,-3Z" fill="${color}" stroke="var(--bench)" stroke-width=".7">${title}</path>`;
  }).join('');
  const [x, y] = state.inference.point;
  $('#boundary').innerHTML = `<svg id="boundary-svg" viewBox="0 0 302 294" role="img" aria-label="Decision boundary from minus two to two on each axis. Use the numeric input controls below to probe a point with the keyboard.">
    <defs><clipPath id="plot-clip"><rect x="${left}" y="${top}" width="${size}" height="${size}" rx="4"/></clipPath></defs>
    <g clip-path="url(#plot-clip)">${cells}<path d="M${left},${py(0)}h${size} M${px(0)},${top}v${size}" stroke="#ffffff20" stroke-dasharray="3 4"/>${points}</g>
    <g fill="var(--muted)" font-size="9" font-family="monospace"><text x="28" y="274">−2</text><text x="153" y="274">0</text><text x="275" y="274">2</text><text x="12" y="14">2</text><text x="12" y="137">0</text><text x="6" y="259">−2</text><text x="153" y="290">x₁</text><text x="4" y="122">x₂</text></g>
    <g transform="translate(${px(x)},${py(y)})" stroke="var(--ink)" fill="none" stroke-width="1.4"><circle r="7"/><path d="M-12,0h6 M6,0h6 M0,-12v6 M0,6v6"/></g></svg>`;
}

export function prediction(inference) {
  const [p0, p1] = inference.probabilities;
  $('#prediction').innerHTML = `<div class="prediction-row"><span>Class 0 · ${(p0 * 100).toFixed(1)}%</span><span>Class 1 · ${(p1 * 100).toFixed(1)}%</span></div><div class="probability-track" role="img" aria-label="Class 0 probability ${(p0 * 100).toFixed(1)} percent; class 1 probability ${(p1 * 100).toFixed(1)} percent"><span style="width:${p0 * 100}%"></span></div><p class="prediction-note">Prediction: <strong>class ${inference.prediction}</strong> · ${Math.max(p0,p1) < .65 ? 'Close to the decision boundary.' : 'The higher probability wins.'}</p><div class="sensitivity">∂P(class ${inference.prediction}) / ∂x = [${inference.sensitivity.map(v => fmt(v, 3)).join(', ')}]</div><p class="field-note">Local sensitivity: how the predicted probability changes for a tiny input change. It is not feature importance or a causal explanation.</p>`;
}

export function lossChart(history) {
  const width = Math.max($('#loss-chart').clientWidth, 220), height = 130, left = 38, top = 8, plotW = width - left - 14, plotH = 96;
  const max = Math.max(...history.flatMap(p => [p.train_loss, p.validation_loss]), .01) * 1.1;
  const minStep = history[0].step, maxStep = Math.max(history.at(-1).step, minStep + 1);
  const x = p => left + (p.step - minStep) / (maxStep - minStep) * plotW;
  const y = v => top + plotH - v / max * plotH;
  const path = key => history.map((p, i) => `${i ? 'L' : 'M'}${x(p)},${y(p[key])}`).join(' ');
  const grid = [0, .5, 1].map(f => `<path d="M${left},${y(max*f)}h${plotW}" stroke="var(--border)"/><text x="0" y="${y(max*f)+3}">${fmt(max*f, 2)}</text>`).join('');
  $('#loss-chart').innerHTML = `<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Training and validation loss across ${history.length} measurements, from step ${minStep} to ${history.at(-1).step}. Latest training loss ${fmt(history.at(-1).train_loss)}; validation loss ${fmt(history.at(-1).validation_loss)}."><g font-size="10" font-family="monospace" fill="var(--muted)">${grid}<text x="${left}" y="126">${minStep}</text><text x="${width-78}" y="126">step ${history.at(-1).step}</text></g><path d="${path('train_loss')}" fill="none" stroke="var(--signal)" stroke-width="2" vector-effect="non-scaling-stroke"/><path d="${path('validation_loss')}" fill="none" stroke="var(--class-one)" stroke-width="2" stroke-dasharray="5 4" vector-effect="non-scaling-stroke"/><circle cx="${x(history.at(-1))}" cy="${y(history.at(-1).train_loss)}" r="3" fill="var(--signal)"/>${history.length === 1 ? `<text x="${left+plotW/2}" y="56" text-anchor="middle" fill="var(--muted)" font-size="11">Run a batch to start.</text>` : ''}</svg>`;
}
