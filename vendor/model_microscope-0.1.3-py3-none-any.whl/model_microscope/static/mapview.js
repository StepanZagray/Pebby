// The model map: every tensor is a column of units, every weight is one drawn edge.
// Nothing is aggregated away and no edge is hidden — zooming is what makes density readable.
import {$, escape as esc, fmt, first, shape} from './common.js';

const COLUMN_GAP = 230;   // horizontal distance between tensor columns, in map units
const UNIT_GAP = 34;      // vertical distance between units inside a column
const R = 11;             // unit radius
const PLATE_PAD = 26;     // padding of the column plate around its units
const MAX_UNITS = 96;     // above this a column is summarised instead of drawn unit by unit
const SUMMARY_HEIGHT = 170; // drawn height of a column that has no unit axis to show
// Headings counter-scale to stay legible, but past this cap the widest module name would
// grow wider than the column spacing and collide with its neighbour, so it shrinks instead.
const HEAD_SCALE_CAP = 1.7;
const MIN_SCALE = 0.15, MAX_SCALE = 8;

let model = null;                 // {columns, gaps, bounds}
let view = {k: 1, x: 0, y: 0};    // scene transform
let selection = {kind: 'layer', column: 0, unit: null, edge: null};
let hover = null;                 // {column, unit} while pointing at a unit
let hoverEdge = null;             // {gap, from, to} while pointing at a weight
let onSelect = () => {};
let viewport = {w: 1, h: 1};

/* Model ------------------------------------------------------------------ */

// The batch dimension leads, so the first example is the first `units` values.
function example(tensor, units) {
  if (!tensor?.values) return null;
  return tensor.values.slice(0, units);
}

export function buildModel(trace) {
  const calls = trace.calls.slice(0, 128);
  const input = first(calls[0]?.inputs);
  const nodes = input ? [{id: -1, name: 'Input', type: 'Features', outputs: {tensor: input}, gradients: {}}, ...calls] : calls;
  const columns = nodes.map((call, index) => {
    const output = first(call.outputs);
    const rank = output?.shape?.length ?? 0;
    const units = output?.shape?.at(-1) || 1;
    // Only [units] or [batch, units] tensors have a unit axis to draw. For a conv tensor
    // like [batch, channels, height, width] the last dimension is width, not a neuron,
    // so the column is shown as one block instead of pretending otherwise.
    const reason = rank > 2 ? `rank ${rank} tensor · no unit axis`
      : units > MAX_UNITS ? `${units} units · too many to draw`
      : null;
    const drawn = reason ? 0 : units;
    return {
      index, id: call.id, name: call.name, type: call.type,
      units, drawn, summarised: !!reason, reason,
      shape: shape(output), tensor: output,
      values: example(output, Math.min(units, MAX_UNITS)),
      gradients: example(first(call.gradients), Math.min(units, MAX_UNITS)),
    };
  });

  const gaps = columns.slice(1).map((column, gapIndex) => {
    const i = gapIndex;
    const source = columns[i];
    const parameter = trace.parameters.find(p => p.name === `${column.name}.weight`);
    const weight = parameter?.value;
    const bias = trace.parameters.find(p => p.name === `${column.name}.bias`)?.value;
    // Per-weight edges are only truthful when the matrix arrived whole and its shape
    // matches the two columns it would connect.
    const usable = weight && !weight.truncated && weight.values
      && weight.shape?.length === 2
      && weight.shape[0] === column.units && weight.shape[1] === source.units
      && !column.summarised && !source.summarised;
    if (usable) {
      const edges = [];
      let max = 0;
      for (let o = 0; o < column.units; o++) {
        for (let i2 = 0; i2 < source.units; i2++) {
          const value = weight.values[o * source.units + i2];
          if (value == null) continue;
          edges.push({from: i2, to: o, value});
          max = Math.max(max, Math.abs(value));
        }
      }
      // Strongest last so the connections that matter are drawn on top.
      edges.sort((a, b) => Math.abs(a.value) - Math.abs(b.value));
      return {index: gapIndex, kind: 'weights', source, target: column, edges, max: max || 1, weight, bias, parameter, name: `${column.name}.weight`};
    }
    if (source.drawn === column.drawn && !source.summarised && !column.summarised) {
      return {index: gapIndex, kind: 'elementwise', source, target: column, edges: Array.from({length: column.drawn}, (_, i2) => ({from: i2, to: i2, value: null})), max: 1};
    }
    const note = column.summarised || source.summarised ? (column.reason || source.reason)
      : weight?.truncated ? 'weight preview truncated by the recorder'
      : 'mapping not recorded';
    return {index: gapIndex, kind: 'bundle', source, target: column, edges: [], max: 1, note};
  });

  for (const column of columns) {
    const height = column.summarised ? SUMMARY_HEIGHT : Math.max(column.drawn - 1, 0) * UNIT_GAP;
    column.x = column.index * COLUMN_GAP;
    column.top = -height / 2;
    column.height = height;
  }
  const half = Math.max(...columns.map(c => c.height)) / 2 + PLATE_PAD + 46;
  model = {
    columns, gaps,
    bounds: {x: -PLATE_PAD - R, y: -half, w: (columns.length - 1) * COLUMN_GAP + 2 * (PLATE_PAD + R), h: 2 * half},
    edgeCount: gaps.reduce((n, g) => n + (g.kind === 'weights' ? g.edges.length : 0), 0),
  };
  if (selection.column >= columns.length) selection = {kind: 'layer', column: 0, unit: null, edge: null};
  return model;
}

export const currentModel = () => model;
export const currentSelection = () => selection;

/* Geometry --------------------------------------------------------------- */

const unitY = (column, unit) => column.top + unit * UNIT_GAP;

function tint(value, max) {
  if (value == null) return 'var(--input)';
  const rgb = value >= 0 ? '76,141,255' : '255,122,102';
  return `rgba(${rgb},${0.14 + 0.62 * Math.min(Math.abs(value) / (max || 1), 1)})`;
}

function columnMax(column) {
  return Math.max(...(column.values || []).filter(v => v != null).map(Math.abs), 1e-6);
}

/* Rendering -------------------------------------------------------------- */

function edgePath(gap, edge) {
  const x1 = gap.source.x + R, y1 = unitY(gap.source, edge.from);
  const x2 = gap.target.x - R, y2 = unitY(gap.target, edge.to);
  const c = (x2 - x1) * 0.45;
  return `M${x1},${y1}C${x1 + c},${y1} ${x2 - c},${y2} ${x2},${y2}`;
}

function renderEdges() {
  return model.gaps.map((gap, index) => {
    if (gap.kind === 'bundle') {
      const x1 = gap.source.x + R, x2 = gap.target.x - R;
      return `<path class="gap-bundle" d="M${x1},${gap.source.top - 8}L${x2},${gap.target.top - 8}L${x2},${gap.target.top + gap.target.height + 8}L${x1},${gap.source.top + gap.source.height + 8}Z"><title>Mapping between ${esc(gap.source.name)} and ${esc(gap.target.name)} is not recorded (${esc(gap.note)}).</title></path>`;
    }
    return gap.edges.map(edge => {
      if (gap.kind === 'elementwise') {
        return `<path class="edge elementwise" data-gap="${index}" d="${edgePath(gap, edge)}"/>`;
      }
      const rel = Math.min(Math.abs(edge.value) / gap.max, 1);
      const width = (0.5 + 3.4 * rel).toFixed(2);
      const opacity = (0.14 + 0.62 * rel).toFixed(3);
      return `<path class="edge weight ${edge.value >= 0 ? 'pos' : 'neg'}" data-gap="${index}" data-from="${edge.from}" data-to="${edge.to}" stroke-width="${width}" opacity="${opacity}" d="${edgePath(gap, edge)}"><title>${esc(gap.name)}[${edge.to}, ${edge.from}] = ${fmt(edge.value)}</title></path>`;
    }).join('');
  }).join('');
}

function renderColumns() {
  return model.columns.map(column => {
    const max = columnMax(column);
    const plateY = column.top - PLATE_PAD, plateH = column.height + 2 * PLATE_PAD;
    const units = column.summarised
      ? `<rect class="unit-summary" data-column="${column.index}" x="${-R - 4}" y="${column.top}" width="${2 * R + 8}" height="${column.height}" rx="9"><title>${esc(column.name)} · ${esc(column.shape)} · ${esc(column.reason)}</title></rect>`
      : Array.from({length: column.drawn}, (_, i) => {
          const value = column.values?.[i];
          const y = unitY(column, i);
          const selected = selection.kind === 'neuron' && selection.column === column.index && selection.unit === i;
          return `<g class="unit${selected ? ' selected' : ''}" data-column="${column.index}" data-unit="${i}" role="button" tabindex="-1" aria-label="${esc(column.name)} unit ${i}, value ${fmt(value)}" transform="translate(0,${y})"><circle class="unit-dot" r="${R}" fill="${tint(value, max)}"/><text class="unit-value" x="0" y="3.5">${value == null ? '—' : fmt(value, 2)}</text></g>`;
        }).join('');
    return `<g class="column${selection.column === column.index ? ' active' : ''}" data-column="${column.index}" transform="translate(${column.x},0)">
      <rect class="plate" x="${-PLATE_PAD - R}" y="${plateY}" width="${2 * (PLATE_PAD + R)}" height="${plateH}" rx="14"/>
      <g class="column-head" data-column="${column.index}" role="button" tabindex="-1" aria-label="Inspect layer ${esc(column.name)}, ${esc(column.type)}, output ${esc(column.shape)}" transform="translate(0,${plateY})">
        <g class="head-inner"><text class="head-name" y="-38">${esc(column.name)}</text><text class="head-type" y="-24">${esc(column.type)}</text><text class="head-shape" y="-10">${esc(column.shape)}</text></g>
      </g>
      ${units}
      ${column.summarised ? `<g transform="translate(0,${plateY + plateH})"><g class="head-inner"><text class="head-note" y="16">no unit axis</text></g></g>` : ''}
    </g>`;
  }).join('');
}

export function render() {
  const svg = $('#map-svg');
  if (!svg || !model) return;
  svg.innerHTML = `<g id="map-scene"><g class="edges">${renderEdges()}</g><g class="columns">${renderColumns()}</g></g>`;
  applyTransform();
  applyEmphasis();
  readout();
  updateChrome();
}

function applyTransform() {
  const scene = $('#map-scene');
  if (scene) scene.setAttribute('transform', `translate(${view.x},${view.y}) scale(${view.k})`);
  const svg = $('#map-svg');
  if (!svg) return;
  // Column headings counter-scale so they stay legible at any zoom; unit values ride the
  // scene scale and are hidden while they would be too small to read.
  svg.style.setProperty('--inverse-scale', Math.min(1 / view.k, HEAD_SCALE_CAP));
  svg.classList.toggle('detail', view.k >= 0.78);
  // Thresholds are the on-screen column spacing at which each heading line would start
  // to touch its neighbour: the module type is the widest, so it goes first.
  const spacing = COLUMN_GAP * view.k;
  svg.classList.toggle('tight', spacing < 118);
  svg.classList.toggle('very-tight', spacing < 96);
}

// Emphasis never removes an edge: it only lowers the contrast of the ones you are not
// pointing at, and it is driven entirely by hover or selection.
function applyEmphasis() {
  const svg = $('#map-svg');
  if (!svg) return;
  const focus = hover || (selection.kind === 'neuron' ? {column: selection.column, unit: selection.unit} : null);
  svg.classList.toggle('focused', !!focus || !!hoverEdge || selection.kind === 'edge');
  for (const path of svg.querySelectorAll('.edge')) {
    const gap = model.gaps[Number(path.dataset.gap)];
    let on = false;
    if (hoverEdge) {
      on = gap.index === hoverEdge.gap && Number(path.dataset.from) === hoverEdge.from && Number(path.dataset.to) === hoverEdge.to;
    } else if (selection.kind === 'edge' && selection.edge) {
      const e = selection.edge;
      on = gap === model.gaps[e.gap] && Number(path.dataset.from) === e.from && Number(path.dataset.to) === e.to;
    } else if (focus) {
      on = (gap.target.index === focus.column && Number(path.dataset.to) === focus.unit)
        || (gap.source.index === focus.column && Number(path.dataset.from) === focus.unit);
    }
    path.classList.toggle('lit', on);
  }
  for (const unit of svg.querySelectorAll('.unit')) {
    unit.classList.toggle('lit', !!focus && Number(unit.dataset.column) === focus.column && Number(unit.dataset.unit) === focus.unit);
  }
}

function readout() {
  const element = $('#map-readout');
  if (!element) return;
  if (hoverEdge) {
    const gap = model.gaps[hoverEdge.gap];
    const value = gap.weight.values[hoverEdge.to * gap.source.units + hoverEdge.from];
    const activation = gap.source.values?.[hoverEdge.from];
    element.innerHTML = `<b>${esc(gap.name)}[${hoverEdge.to}, ${hoverEdge.from}]</b> = <span class="${value >= 0 ? 'pos' : 'neg'}">${fmt(value)}</span>`
      + (activation == null ? '' : ` &nbsp;·&nbsp; w·x = ${fmt(activation * value, 3)}`);
  } else if (hover) {
    const column = model.columns[hover.column];
    element.innerHTML = `<b>${esc(column.name)}[${hover.unit}]</b> = ${fmt(column.values?.[hover.unit])}`
      + (column.gradients?.[hover.unit] == null ? '' : ` &nbsp;·&nbsp; ∂loss/∂output = ${fmt(column.gradients[hover.unit], 3)}`);
  } else {
    element.innerHTML = '';
  }
  element.hidden = !hoverEdge && !hover;
}

function updateChrome() {
  const zoom = $('#map-zoom');
  if (zoom) zoom.textContent = `${Math.round(view.k * 100)}%`;
  const count = $('#map-edge-count');
  if (count && model) {
    const bundles = model.gaps.filter(g => g.kind === 'bundle').length;
    count.textContent = `${model.columns.length} tensors · ${model.edgeCount.toLocaleString()} weights drawn${bundles ? ` · ${bundles} gap${bundles > 1 ? 's' : ''} with no drawable mapping` : ''}`;
  }
}

/* Zoom and pan ----------------------------------------------------------- */

function clampScale(k) { return Math.min(MAX_SCALE, Math.max(MIN_SCALE, k)); }

export function zoomTo(k, cx, cy) {
  const next = clampScale(k);
  const px = cx ?? viewport.w / 2, py = cy ?? viewport.h / 2;
  view.x = px - (px - view.x) * (next / view.k);
  view.y = py - (py - view.y) * (next / view.k);
  view.k = next;
  applyTransform();
  updateChrome();
}

export function fit(animate = false) {
  if (!model) return;
  const b = model.bounds;
  const pad = 48;
  const k = clampScale(Math.min((viewport.w - pad * 2) / b.w, (viewport.h - pad * 2) / b.h));
  view = {k, x: viewport.w / 2 - (b.x + b.w / 2) * k, y: viewport.h / 2 - (b.y + b.h / 2) * k};
  const svg = $('#map-svg');
  if (animate && svg && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
    svg.classList.add('animating');
    setTimeout(() => svg.classList.remove('animating'), 320);
  }
  applyTransform();
  updateChrome();
}

// Bring a unit to the middle of the viewport without changing the zoom level.
export function centerOn(columnIndex, unit) {
  const column = model?.columns[columnIndex];
  if (!column) return;
  const y = unit == null ? 0 : unitY(column, unit);
  view.x = viewport.w / 2 - column.x * view.k;
  view.y = viewport.h / 2 - y * view.k;
  applyTransform();
}

/* Interaction ------------------------------------------------------------ */

function select(next) {
  selection = {kind: 'layer', column: 0, unit: null, edge: null, ...next};
  render();
  onSelect(selection);
}

function localPoint(event) {
  const rect = $('#map-svg').getBoundingClientRect();
  return {x: event.clientX - rect.left, y: event.clientY - rect.top};
}

export function initMap(handler) {
  onSelect = handler;
  const stage = $('#map-stage'), svg = $('#map-svg');

  const measure = () => {
    const rect = stage.getBoundingClientRect();
    const first = viewport.w <= 1;
    viewport = {w: rect.width, h: rect.height};
    svg.setAttribute('viewBox', `0 0 ${rect.width} ${rect.height}`);
    if (first) fit();
  };
  new ResizeObserver(measure).observe(stage);
  measure();

  svg.addEventListener('wheel', event => {
    event.preventDefault();
    const {x, y} = localPoint(event);
    // Trackpad pinch arrives as a ctrl-wheel; both gestures mean zoom here.
    const factor = Math.exp(-(event.deltaMode === 1 ? event.deltaY * 18 : event.deltaY) * 0.0016);
    zoomTo(view.k * factor, x, y);
  }, {passive: false});

  let dragging = null;
  svg.addEventListener('pointerdown', event => {
    if (event.button !== 0) return;
    // Pointer capture retargets later events to the <svg>, so remember what was actually
    // under the cursor when the press started.
    dragging = {id: event.pointerId, x: event.clientX, y: event.clientY, moved: false, target: event.target};
    svg.setPointerCapture(event.pointerId);
  });
  svg.addEventListener('pointermove', event => {
    if (dragging && dragging.id === event.pointerId) {
      const dx = event.clientX - dragging.x, dy = event.clientY - dragging.y;
      if (Math.abs(dx) + Math.abs(dy) > 3) dragging.moved = true;
      view.x += dx; view.y += dy;
      dragging.x = event.clientX; dragging.y = event.clientY;
      svg.classList.toggle('panning', dragging.moved);
      applyTransform();
      return;
    }
    const unit = event.target.closest('.unit');
    const edge = unit ? null : event.target.closest('.edge.weight');
    const next = unit ? {column: Number(unit.dataset.column), unit: Number(unit.dataset.unit)} : null;
    const nextEdge = edge ? {gap: Number(edge.dataset.gap), from: Number(edge.dataset.from), to: Number(edge.dataset.to)} : null;
    if (JSON.stringify(next) !== JSON.stringify(hover) || JSON.stringify(nextEdge) !== JSON.stringify(hoverEdge)) {
      hover = next; hoverEdge = nextEdge; applyEmphasis(); readout();
    }
  });
  const endDrag = event => {
    if (!dragging || dragging.id !== event.pointerId) return;
    const {moved, target} = dragging;
    dragging = null;
    svg.classList.remove('panning');
    if (moved || !target.closest) return;
    const unit = target.closest('.unit');
    const head = target.closest('.column-head, .plate, .unit-summary');
    const edge = target.closest('.edge.weight');
    if (unit) select({kind: 'neuron', column: Number(unit.dataset.column), unit: Number(unit.dataset.unit)});
    else if (edge) {
      const gap = Number(edge.dataset.gap);
      select({kind: 'edge', column: model.gaps[gap].target.index, unit: Number(edge.dataset.to),
              edge: {gap, from: Number(edge.dataset.from), to: Number(edge.dataset.to)}});
    } else if (head) select({kind: 'layer', column: Number(head.closest('.column').dataset.column)});
    else if (selection.kind !== 'layer') select({kind: 'layer', column: selection.column});
  };
  svg.addEventListener('pointerup', endDrag);
  svg.addEventListener('pointercancel', () => { dragging = null; svg.classList.remove('panning'); });
  svg.addEventListener('pointerleave', () => {
    if (hover || hoverEdge) { hover = null; hoverEdge = null; applyEmphasis(); readout(); }
  });

  svg.addEventListener('dblclick', event => {
    event.preventDefault();
    const {x, y} = localPoint(event);
    zoomTo(view.k * 1.8, x, y);
  });

  // Roving 2-D keyboard navigation: columns on the horizontal axis, units on the vertical.
  svg.addEventListener('keydown', event => {
    const step = 60 / view.k;
    const moves = {
      ArrowLeft: () => move(-1, 0), ArrowRight: () => move(1, 0),
      ArrowUp: () => move(0, -1), ArrowDown: () => move(0, 1),
      Home: () => select({kind: 'layer', column: 0}),
      End: () => select({kind: 'layer', column: model.columns.length - 1}),
      '+': () => zoomTo(view.k * 1.3), '=': () => zoomTo(view.k * 1.3),
      '-': () => zoomTo(view.k / 1.3), '0': () => fit(true),
    };
    if (event.shiftKey && event.key.startsWith('Arrow')) {
      const [dx, dy] = {ArrowLeft: [1, 0], ArrowRight: [-1, 0], ArrowUp: [0, 1], ArrowDown: [0, -1]}[event.key];
      view.x += dx * step * view.k; view.y += dy * step * view.k;
      applyTransform();
      event.preventDefault();
      return;
    }
    const action = moves[event.key];
    if (!action) return;
    event.preventDefault();
    action();
  });

  function move(dx, dy) {
    const column = Math.min(Math.max(selection.column + dx, 0), model.columns.length - 1);
    const target = model.columns[column];
    if (dy === 0) {
      const unit = selection.unit == null ? null : Math.min(selection.unit, target.drawn - 1);
      select(unit == null || target.summarised ? {kind: 'layer', column} : {kind: 'neuron', column, unit});
    } else {
      if (target.summarised) return;
      const unit = selection.unit == null ? (dy > 0 ? 0 : target.drawn - 1)
        : Math.min(Math.max(selection.unit + dy, 0), target.drawn - 1);
      select({kind: 'neuron', column, unit});
    }
    centerOn(selection.column, selection.unit);
  }

  $('#map-zoom-in').addEventListener('click', () => zoomTo(view.k * 1.4));
  $('#map-zoom-out').addEventListener('click', () => zoomTo(view.k / 1.4));
  $('#map-fit').addEventListener('click', () => fit(true));
}

// Re-render after new data, keeping the camera and the selection where the user left them.
export function update(trace) {
  const previous = model;
  buildModel(trace);
  if (!previous || previous.columns.length !== model.columns.length) {
    selection = {kind: 'layer', column: 0, unit: null, edge: null};
    render();
    fit();
  } else {
    render();
  }
}

export function selectLayer(columnIndex) { select({kind: 'layer', column: columnIndex}); }
export function selectUnit(columnIndex, unit) { select({kind: 'neuron', column: columnIndex, unit}); }
export function selectEdge(gap, from, to) {
  select({kind: 'edge', column: model.gaps[gap].target.index, unit: to, edge: {gap, from, to}});
}
