// Only data is accepted. Never deserialize a checkpoint or execute uploaded Python.
export function parseTrace(text) {
  const document = JSON.parse(text);
  const trace = document.format === 'model-microscope.experiment.v1' ? document.trace || document.inference?.trace : document;
  const fail = () => { throw new Error('Invalid trace. Export with model_microscope.TraceRecorder (format v1).'); };
  if (!trace || trace.format !== 'model-microscope.trace.v1' || !Array.isArray(trace.calls) || trace.calls.length > 1024 || !Array.isArray(trace.parameters) || trace.parameters.length > 10000) fail();
  const isText = v => typeof v === 'string' && v.length <= 4096;
  const isNumber = v => v === null || (typeof v === 'number' && Number.isFinite(v));
  function tensor(t) {
    if (!t || !Array.isArray(t.shape) || t.shape.length > 32 || t.shape.some(n => !Number.isSafeInteger(n) || n < 0) || !Number.isSafeInteger(t.numel) || t.numel < 0 || !isText(t.dtype) || !isText(t.device)) fail();
    if (t.unsupported) { if (!isText(t.unsupported)) fail(); return; }
    if (!Number.isSafeInteger(t.nonfinite) || t.nonfinite < 0 || t.nonfinite > t.numel || typeof t.truncated !== 'boolean') fail();
    if (!Array.isArray(t.values) || t.values.length > 4096 || t.values.some(v => !isNumber(v))) fail();
    for (const key of ['mean', 'std', 'norm', 'min', 'max', 'zero_fraction']) if (!isNumber(t[key])) fail();
  }
  const ids = new Set();
  for (const c of trace.calls) {
    if (!Number.isSafeInteger(c.id) || c.id < 0 || ids.has(c.id) || !isText(c.name) || !isText(c.type)) fail();
    ids.add(c.id);
    for (const field of ['inputs','outputs','gradients']) {
      if (!c[field] || typeof c[field] !== 'object' || Array.isArray(c[field]) || Object.keys(c[field]).length > 1024) fail();
      Object.values(c[field]).forEach(tensor);
    }
  }
  for (const p of trace.parameters) { if (!isText(p.name)) fail(); tensor(p.value); if (p.gradient !== null) tensor(p.gradient); }
  return trace;
}
