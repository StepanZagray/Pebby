import {$, escape as esc, fmt, shape} from './common.js';

function tint(value, max) {
  if (value == null) return 'var(--input)';
  const rgb = value >= 0 ? '76,141,255' : '255,122,102';
  return `rgba(${rgb},${0.12 + 0.44 * Math.min(Math.abs(value) / (max || 1), 1)})`;
}

function stats(tensor) {
  return `<div class="tensor-stats">${[['Mean', tensor.mean], ['Std dev', tensor.std], ['L2 norm', tensor.norm], ['Minimum', tensor.min], ['Maximum', tensor.max], ['Zero values', tensor.zero_fraction == null ? null : tensor.zero_fraction * 100]].map(([name, value]) => `<div><span>${name}</span><strong>${fmt(value, name === 'Zero values' ? 1 : 4)}${name === 'Zero values' && value != null ? '%' : ''}</strong></div>`).join('')}</div>`;
}

function tensorView(tensor, label) {
  if (tensor.unsupported) return `<p class="tensor-note">${esc(tensor.unsupported)}</p>`;
  const values = (tensor.values || []).slice(0, 128);
  const max = Math.max(...values.filter(v => v != null).map(Math.abs), .000001);
  const cols = Math.min(tensor.shape?.at(-1) || 1, 8);
  return `<div class="tensor-label">${esc(label)} &nbsp; ${esc(shape(tensor))} · ${esc(tensor.dtype)} · ${esc(tensor.device || '')}</div><div class="tensor-grid" style="--columns:${cols}" role="img" aria-label="${esc(label)} tensor preview, ${values.length} of ${tensor.numel} values; rounded values are listed in the cells; exact preview values follow">${values.map((v, i) => `<span class="tensor-cell" style="background:${tint(v, max)}" title="Flat index ${i}: ${v ?? 'non-finite'}">${v != null && Math.abs(v) > 0 && (Math.abs(v) < .01 || Math.abs(v) >= 1000) ? v.toExponential(0) : fmt(v, 2)}</span>`).join('')}</div><p class="field-note">First ${values.length} / ${tensor.numel.toLocaleString()} values in flattened order. Color is scaled to this preview. Statistics cover all finite values.${tensor.nonfinite ? ` ${tensor.nonfinite} non-finite values are shown as — and excluded from statistics.` : ''}</p>${stats(tensor)}<details class="exact-values"><summary>Exact preview values</summary><pre>${esc(JSON.stringify(values))}</pre></details>`;
}

/* Layer view ------------------------------------------------------------- */

function layerView(context) {
  const {trace, column, view, tensorKey, mode, phase, deltas, imported} = context;
  const call = trace.calls.find(c => c.id === column.id)
    || {name: column.name, type: column.type, outputs: {tensor: column.tensor}, gradients: {}};
  let tensors = call[view] || {};
  if (view === 'weights') {
    tensors = Object.fromEntries(trace.parameters
      .filter(p => p.name.startsWith(`${call.name}.`) || (call.name === 'model' && !p.name.includes('.')))
      .map(p => [p.name, p.value]));
  }
  const keys = Object.keys(tensors).filter(k => tensors[k]);
  const key = keys.includes(tensorKey) ? tensorKey : keys[0];
  if (!key) {
    const message = view === 'gradients'
      ? (mode === 'inference' && !imported ? 'Inference doesn’t compute loss gradients.' : 'No output gradient captured for this layer.')
      : 'This layer has no learned weights.';
    const detail = view === 'gradients'
      ? 'Run the backward phase in training to see ∂loss/∂output. A missing gradient is not zero: the tensor may not require gradients or may not contribute to the loss.'
      : 'Activation functions transform values using a fixed rule. Select a Linear layer to inspect its weights and biases.';
    return `<div class="empty-state"><strong>${message}</strong><p>${detail}</p></div>`;
  }
  const select = keys.length > 1
    ? `<label for="tensor-select" class="sr-only">Tensor to inspect</label><select id="tensor-select" class="tensor-select">${keys.map(k => `<option value="${esc(k)}" ${k === key ? 'selected' : ''}>${esc(k)}</option>`).join('')}</select>`
    : '';
  const notes = {
    outputs: imported
      ? 'These values were captured when this module returned. They are specific to the recorded input.'
      : mode === 'training' && phase !== 'ready'
        ? 'The leading dimension is the batch: 32 examples. The map draws the first example; these statistics cover the whole tensor.'
        : 'These activations come from the single probe point. Change its coordinates to see how the same weights transform a different input.',
    gradients: '∂loss/∂output: sensitivity of the scalar loss to this layer’s output. The demo averages loss over 32 examples. Values are signed; a larger magnitude means a stronger local effect, not a more important neuron.',
    weights: imported
      ? 'Learned parameters at the time this trace was exported.'
      : 'A Linear layer stores weights as [output units × input features]. Each row combines the previous tensor’s values into one output. Bias adds a learned offset.',
  };
  const parameter = trace.parameters.find(p => p.name === key);
  const weight = view === 'weights'
    ? `<div class="weight-summary">Parameter gradient norm: <strong>${fmt(parameter?.gradient?.norm)}</strong><br>Last update norm: <strong>${fmt(deltas?.[key]?.norm)}</strong>${!imported && phase === 'update' && mode === 'training' ? '<p class="field-note">Weights are after the optimizer update. Gradients and activations belong to the preceding forward/backward pass.</p>' : ''}</div>`
    : '';
  return select + tensorView(tensors[key], view === 'gradients' ? `∂loss/∂${key}` : key) + `<p class="tensor-note">${notes[view]}</p>` + weight;
}

/* Unit view -------------------------------------------------------------- */

// Gradients and updates are routinely smaller than 0.005, where two decimals would
// render every one of them as "0.00".
const compact = value => value == null || !Number.isFinite(value) ? '—'
  : Math.abs(value) > 0 && Math.abs(value) < 0.01 ? value.toExponential(1) : value.toFixed(2);

function bar(value, max) {
  const rel = Math.min(Math.abs(value) / (max || 1), 1) * 50;
  return `<span class="bar" aria-hidden="true"><i class="${value >= 0 ? 'pos' : 'neg'}" style="width:${rel}%;${value >= 0 ? 'left' : 'right'}:50%"></i></span>`;
}

function connectionRows(gap, unit, direction, deltas) {
  const edges = gap.edges.filter(e => (direction === 'in' ? e.to : e.from) === unit);
  const source = direction === 'in' ? gap.source : gap.target;
  const other = e => (direction === 'in' ? e.from : e.to);
  const rows = edges.map(e => {
    // Either way the driving value is the one on the left of this gap: for an incoming
    // edge that is the other unit, for an outgoing edge it is this unit itself.
    const activation = gap.source.values?.[e.from];
    return {edge: e, index: other(e), activation, product: activation == null ? null : activation * e.value};
  }).sort((a, b) => Math.abs(b.product ?? b.edge.value) - Math.abs(a.product ?? a.edge.value));
  const max = Math.max(...rows.map(r => Math.abs(r.edge.value)), 1e-9);
  const gradient = gap.parameter?.gradient;
  const delta = deltas?.[gap.name];
  return `<ul class="connections" role="list">${rows.map(r => {
    const flat = r.edge.to * gap.source.units + r.edge.from;
    return `<li><button class="connection" data-gap="${gap.index}" data-from="${r.edge.from}" data-to="${r.edge.to}">
      <span class="connection-unit">${esc(source.name)}<b>[${r.index}]</b></span>
      <span class="connection-value">${fmt(r.edge.value, 3)}</span>
      <span class="connection-meta">
        ${bar(r.edge.value, max)}
        ${r.product == null ? '' : `<span>w·x <b>${compact(r.product)}</b></span>`}
        ${gradient?.values ? `<span>∂L <b>${compact(gradient.values[flat])}</b></span>` : ''}
        ${delta?.values ? `<span>Δ <b>${compact(delta.values[flat])}</b></span>` : ''}
      </span>
    </button></li>`;
  }).join('')}</ul>`;
}

function unitView(context) {
  const {model, column, selection, deltas, mode, phase, imported} = context;
  const unit = selection.unit;
  const value = column.values?.[unit];
  const gradient = column.gradients?.[unit];
  const incoming = model.gaps[column.index - 1];
  const outgoing = model.gaps[column.index];
  const bias = incoming?.bias?.values?.[unit];

  let reconstruction = '';
  if (incoming?.kind === 'weights' && incoming.source.values) {
    const sum = incoming.edges
      .filter(e => e.to === unit)
      .reduce((total, e) => total + (incoming.source.values[e.from] ?? 0) * e.value, 0);
    const total = sum + (bias ?? 0);
    const residual = value == null ? null : total - value;
    // After an optimizer step the drawn weights are newer than the recorded activations,
    // so the recomputed sum legitimately drifts from the output. Say so rather than hide it.
    const note = residual == null ? 'Recomputed in the browser from the drawn edges.'
      : Math.abs(residual) < 1e-5 ? 'Recomputed in the browser from the drawn edges, and it matches the recorded output above.'
      : phase === 'update' && mode === 'training' && !imported
        ? `Recomputed from the drawn edges. It differs from the recorded output by ${fmt(residual, 5)} because the weights on the map are the ones the optimizer has just written, while the activations are from the forward pass that preceded the update.`
        : `Recomputed from the drawn edges. It differs from the recorded output by ${fmt(residual, 5)}.`;
    reconstruction = `<div class="readout">
      <div><span>Σ w·x</span><strong>${fmt(sum)}</strong></div>
      <div><span>bias</span><strong>${fmt(bias)}</strong></div>
      <div><span>Σ w·x + b</span><strong>${fmt(total)}</strong></div>
    </div><p class="field-note">${note}</p>`;
  }

  const sections = [];
  sections.push(`<div class="readout">
    <div><span>Output</span><strong>${fmt(value)}</strong></div>
    <div><span>∂loss/∂output</span><strong>${fmt(gradient)}</strong></div>
  </div>`);
  if (reconstruction) sections.push(reconstruction);
  if (incoming?.kind === 'weights') {
    sections.push(`<h4>Incoming <span class="count">${incoming.source.units} weights from ${esc(incoming.source.name)}</span></h4>${connectionRows(incoming, unit, 'in', deltas)}`);
  } else if (incoming?.kind === 'elementwise') {
    sections.push(`<h4>Incoming</h4><p class="tensor-note">${esc(column.type)} transforms <code>${esc(incoming.source.name)}[${unit}]</code> = ${fmt(incoming.source.values?.[unit])} element by element. There are no weights on this step.</p>`);
  } else if (incoming) {
    sections.push(`<h4>Incoming</h4><p class="tensor-note">The mapping from ${esc(incoming.source.name)} was not recorded, so individual connections cannot be shown (${esc(incoming.note || 'unknown')}).</p>`);
  }
  if (outgoing?.kind === 'weights') {
    sections.push(`<h4>Outgoing <span class="count">${outgoing.target.units} weights into ${esc(outgoing.target.name)}</span></h4>${connectionRows(outgoing, unit, 'out', deltas)}`);
  }
  const context_note = imported ? 'Recorded input.'
    : mode === 'training' && phase !== 'ready' ? 'First example of the current batch of 32.'
    : 'The single probe point.';
  sections.push(`<p class="field-note">Values shown for: ${context_note}</p>`);
  return sections.join('');
}

/* Edge view -------------------------------------------------------------- */

function edgeView(context) {
  const {model, selection, deltas} = context;
  const gap = model.gaps[selection.edge.gap];
  const {from, to} = selection.edge;
  const flat = to * gap.source.units + from;
  const value = gap.weight.values[flat];
  const activation = gap.source.values?.[from];
  const product = activation == null ? null : activation * value;
  const gradient = gap.parameter?.gradient?.values?.[flat];
  const delta = deltas?.[gap.name]?.values?.[flat];
  const rank = gap.edges.filter(e => Math.abs(e.value) > Math.abs(value)).length + 1;
  const total = gap.edges.filter(e => e.to === to)
    .reduce((sum, e) => sum + Math.abs((gap.source.values?.[e.from] ?? 0) * e.value), 0);
  const share = product == null || !total ? null : Math.abs(product) / total * 100;
  return `<div class="edge-route">
      <button class="route-node" data-column="${gap.source.index}" data-unit="${from}">${esc(gap.source.name)}<b>[${from}]</b><em>${fmt(activation, 3)}</em></button>
      <span class="route-arrow ${value >= 0 ? 'pos' : 'neg'}" aria-hidden="true">→</span>
      <button class="route-node" data-column="${gap.target.index}" data-unit="${to}">${esc(gap.target.name)}<b>[${to}]</b><em>${fmt(gap.target.values?.[to], 3)}</em></button>
    </div>
    <div class="readout">
      <div><span>Weight</span><strong>${fmt(value)}</strong></div>
      <div><span>w · x</span><strong>${fmt(product)}</strong></div>
      <div><span>∂loss/∂w</span><strong>${fmt(gradient)}</strong></div>
      <div><span>Last update</span><strong>${fmt(delta)}</strong></div>
    </div>
    <p class="tensor-note"><code>${esc(gap.name)}[${to}, ${from}]</code> is the ${rank === 1 ? 'strongest' : `${rank}${['th', 'st', 'nd', 'rd'][rank % 10 > 3 || (rank % 100 - rank % 10) === 10 ? 0 : rank % 10]} strongest`} of ${gap.edges.length.toLocaleString()} weights in this step.${share == null ? '' : ` It supplies ${share.toFixed(1)}% of the magnitude reaching <code>${esc(gap.target.name)}[${to}]</code>.`}</p>
    <p class="field-note">w·x is this connection’s term in the target’s weighted sum for the example currently shown. It is one addend, not an attribution or an importance score.</p>`;
}

/* Entry point ------------------------------------------------------------ */

export function inspect(context) {
  const {model, selection} = context;
  const column = model.columns[selection.column];
  const content = $('#inspector-content');
  if (!column) { content.innerHTML = '<div class="empty-state"><strong>No module calls captured</strong><p>The model may use functional operations only, or the trace may have been saved before a forward pass.</p></div>'; return; }
  context.column = column;

  const kind = selection.kind;
  $('.inspector-tabs').hidden = kind !== 'layer';
  $('#layer-type').textContent = kind === 'edge' ? 'Weight' : kind === 'neuron' ? 'Unit' : column.type;
  $('#inspector-title').textContent =
    kind === 'edge' ? `${column.name}[${selection.edge.to}] ← ${model.gaps[selection.edge.gap].source.name}[${selection.edge.from}]`
    : kind === 'neuron' ? `${column.name}[${selection.unit}]`
    : column.name;
  $('#inspector-scope').textContent =
    kind === 'edge' ? 'One weight' : kind === 'neuron' ? `Unit ${selection.unit} of ${column.units} · ${column.type}` : `${column.type} · ${column.shape}`;

  content.innerHTML =
    kind === 'edge' ? edgeView(context)
    : kind === 'neuron' ? unitView(context)
    : layerView(context);
}
