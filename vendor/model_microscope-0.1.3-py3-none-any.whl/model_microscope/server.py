"""Local, bounded, per-browser experiments. No model uploads or remote execution."""

from __future__ import annotations

import argparse
import threading
import time
import uuid
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from importlib.metadata import version
from pathlib import Path
from typing import Literal

import torch
from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .engine import Configuration, Experiment


class StepRequest(BaseModel):
    kind: Literal["phase", "batch"] = "phase"
    count: int = Field(default=1, ge=1, le=20)


class ProbeRequest(BaseModel):
    x: float = Field(ge=-2, le=2, allow_inf_nan=False)
    y: float = Field(ge=-2, le=2, allow_inf_nan=False)


@dataclass
class Session:
    experiment: Experiment
    touched: float = field(default_factory=time.monotonic)


def create_app() -> FastAPI:
    torch.set_num_threads(1)
    sessions: dict[str, Session] = {}
    # One lock also serializes RNG initialization and expiry with active computations.
    lock = threading.RLock()

    @asynccontextmanager
    async def lifespan(app):
        try:
            yield
        finally:
            with lock:
                for current in sessions.values():
                    current.experiment.close()
                sessions.clear()

    app = FastAPI(title="Model Microscope", version=version("model-microscope"), lifespan=lifespan)
    static = Path(__file__).parent / "static"
    app.mount("/static", StaticFiles(directory=static), name="static")

    def session(request: Request, response: Response) -> Session:
        now = time.monotonic()
        for key in list(sessions):
            if now - sessions[key].touched > 3600:
                sessions.pop(key).experiment.close()
        key = request.cookies.get("microscope_session")
        if key not in sessions:
            if len(sessions) >= 16:
                raise HTTPException(429, "All 16 experiment slots are in use. Try again later.")
            key = uuid.uuid4().hex
            sessions[key] = Session(Experiment())
            response.set_cookie("microscope_session", key, httponly=True, samesite="strict")
        sessions[key].touched = now
        return sessions[key]

    @app.middleware("http")
    async def local_origin(request: Request, call_next):
        # Protect the localhost service against cross-origin writes from other websites.
        if request.method == "POST":
            origin = request.headers.get("origin")
            if origin and origin != str(request.base_url).rstrip("/"):
                return Response("Cross-origin requests are not allowed", status_code=403)
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data:; connect-src 'self'; object-src 'none'; "
            "frame-ancestors 'none'; base-uri 'self'"
        )
        response.headers["Cache-Control"] = "no-store"
        return response

    @app.get("/", include_in_schema=False)
    def index():
        return FileResponse(static / "index.html")

    @app.get("/api/state")
    def state(request: Request, response: Response):
        with lock:
            return session(request, response).experiment.state()

    @app.post("/api/reset")
    def reset(config: Configuration, request: Request, response: Response):
        with lock:
            current = session(request, response)
            current.experiment.close()
            current.experiment = Experiment(config)
            return current.experiment.state()

    @app.post("/api/step")
    def step(command: StepRequest, request: Request, response: Response):
        with lock:
            experiment = session(request, response).experiment
            for _ in range(command.count):
                if command.kind == "phase":
                    experiment.advance()
                else:
                    experiment.train_batch()
            return experiment.state()

    @app.post("/api/infer")
    def infer(probe: ProbeRequest, request: Request, response: Response):
        with lock:
            return session(request, response).experiment.infer([probe.x, probe.y])

    @app.get("/api/export")
    def export(request: Request, response: Response):
        with lock:
            response.headers["Content-Disposition"] = 'attachment; filename="experiment.json"'
            return {
                "format": "model-microscope.experiment.v1",
                **session(request, response).experiment.state(),
            }

    return app


def main():
    import uvicorn

    parser = argparse.ArgumentParser(description="Open a local PyTorch learning laboratory")
    parser.add_argument(
        "--version", action="version", version=f"%(prog)s {version('model-microscope')}"
    )
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", default=8000, type=int)
    args = parser.parse_args()
    uvicorn.run(create_app(), host=args.host, port=args.port)


if __name__ == "__main__":
    main()
