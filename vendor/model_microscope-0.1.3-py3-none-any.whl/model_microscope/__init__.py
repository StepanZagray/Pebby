"""Inspect real PyTorch computations with bounded, portable traces."""

from .tracing import TraceRecorder

__all__ = ["TraceRecorder"]
