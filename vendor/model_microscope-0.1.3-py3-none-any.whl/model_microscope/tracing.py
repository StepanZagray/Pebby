"""Leaf-module invocation traces, not a complete operator-level computation graph."""

from __future__ import annotations

import json
import math
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import torch
from torch import Tensor, nn


def tensor_summary(tensor: Tensor, limit: int = 64) -> dict[str, Any]:
    """Copy bounded previews; statistics cover all finite elements, with population std."""
    result: dict[str, Any] = {
        "shape": list(tensor.shape),
        "dtype": str(tensor.dtype),
        "device": str(tensor.device),
        "numel": tensor.numel(),
    }
    if (
        tensor.layout != torch.strided
        or tensor.is_complex()
        or tensor.is_quantized
        or tensor.device.type == "meta"
    ):
        return {
            **result,
            "unsupported": "Preview requires a materialized, dense, real, non-quantized tensor.",
        }
    with torch.no_grad():
        values = tensor.detach().reshape(-1)
        # CPU float64 supports float8 finiteness checks and avoids MPS float64 limitations.
        # Preserve the source representation for previews, including int64 values.
        statistics = values.to(device="cpu", dtype=torch.float64)
        finite = statistics[torch.isfinite(statistics)]
        result.update(
            {
                "values": [v if math.isfinite(v) else None for v in values[:limit].cpu().tolist()],
                "truncated": values.numel() > limit,
                "nonfinite": values.numel() - finite.numel(),
                "min": finite.min().item() if finite.numel() else None,
                "max": finite.max().item() if finite.numel() else None,
                "mean": finite.mean().item() if finite.numel() else None,
                "std": finite.std(unbiased=False).item() if finite.numel() else None,
                "norm": finite.norm().item() if finite.numel() else None,
                "zero_fraction": (finite == 0).float().mean().item() if finite.numel() else None,
            }
        )
        # Extremely large, finite values can still overflow an aggregate (e.g. L2 norm).
        for key, value in result.items():
            if isinstance(value, float) and not math.isfinite(value):
                result[key] = None
    return result


def tensors_in(value: Any, path: str = ""):
    if isinstance(value, Tensor):
        yield path or "tensor", value
    elif isinstance(value, (tuple, list)):
        for index, item in enumerate(value):
            yield from tensors_in(item, f"{path}[{index}]")
    elif isinstance(value, dict):
        for key, item in value.items():
            yield from tensors_in(item, f"{path}.{key}")


class TraceRecorder:
    """Record leaf calls and d(loss)/d(output) without retaining tensor graphs.

    Keep the context open through backward to capture gradients. Existing training modes,
    parameter gradients, and model outputs are never changed by the recorder. Hooks add
    overhead and may synchronize accelerator tensors. Use with eager execution.
    """

    def __init__(self, model: nn.Module, *, max_values: int = 64, max_calls: int = 128):
        if not 1 <= max_values <= 4096 or not 1 <= max_calls <= 1024:
            raise ValueError("max_values must be 1..4096 and max_calls must be 1..1024")
        self.model = model
        self.max_values = max_values
        self.max_calls = max_calls
        self.calls: list[dict[str, Any]] = []
        self.dropped_calls = 0
        self._handles: list[Any] = []
        self._active = False
        self._paused = False
        self._pending: dict[str, list] = {}

    def __enter__(self):
        if self._active:
            raise RuntimeError("A recorder cannot be entered twice concurrently")
        self.calls = []
        self.dropped_calls = 0
        self._pending = {}
        self._active = True
        try:
            for name, module in self.model.named_modules():
                if not list(module.children()):
                    self._handles.append(
                        module.register_forward_pre_hook(
                            self._pre_hook(name or "model"),
                            with_kwargs=True,
                        )
                    )
                    self._handles.append(
                        module.register_forward_hook(
                            self._hook(name or "model"),
                            with_kwargs=True,
                            always_call=True,
                        )
                    )
        except Exception:
            self.close()
            raise
        return self

    def _pre_hook(self, name: str):
        def capture_inputs(module, args, kwargs):
            inputs = None
            if not self._paused and len(self.calls) < self.max_calls:
                inputs = {
                    key: tensor_summary(tensor, self.max_values)
                    for key, tensor in tensors_in({"args": args, "kwargs": kwargs})
                }
            self._pending.setdefault(name, []).append(inputs)

        return capture_inputs

    def _hook(self, name: str):
        def capture(module, args, kwargs, output):
            pending = self._pending.get(name, [])
            inputs = pending.pop() if pending else None
            if self._paused:
                return
            if len(self.calls) >= self.max_calls:
                self.dropped_calls += 1
                return
            call = {
                "id": len(self.calls),
                "name": name,
                "type": type(module).__name__,
                "parameters": sum(p.numel() for p in module.parameters(recurse=False)),
                "inputs": inputs or {},
                "outputs": {},
                "gradients": {},
            }
            for key, tensor in tensors_in(output):
                call["outputs"][key] = tensor_summary(tensor, self.max_values)
                if tensor.requires_grad:

                    def capture_gradient(gradient, record=call, output_key=key):
                        # Returning None preserves the original gradient.
                        record["gradients"][output_key] = tensor_summary(gradient, self.max_values)

                    self._handles.append(tensor.register_hook(capture_gradient))
            self.calls.append(call)

        return capture

    @contextmanager
    def pause(self):
        """Exclude unrelated forward calls without removing pending gradient hooks."""
        previous = self._paused
        self._paused = True
        try:
            yield
        finally:
            self._paused = previous

    def close(self):
        for handle in self._handles:
            handle.remove()
        self._handles.clear()
        self._pending.clear()
        self._active = False

    def __exit__(self, *_):
        self.close()

    def snapshot(self) -> dict[str, Any]:
        """Return a detached JSON-compatible copy, including parameter gradient summaries."""
        result = {
            "format": "model-microscope.trace.v1",
            "model": type(self.model).__name__,
            "scope": "Leaf-module invocation order; functional ops and residual edges are not traced.",
            "max_values": self.max_values,
            "max_calls": self.max_calls,
            "dropped_calls": self.dropped_calls,
            "calls": self.calls,
            "parameters": [
                {
                    "name": name,
                    "value": tensor_summary(param, self.max_values),
                    "gradient": tensor_summary(param.grad, self.max_values)
                    if param.grad is not None
                    else None,
                }
                for name, param in self.model.named_parameters()
            ],
        }
        return json.loads(json.dumps(result, allow_nan=False))

    def save(self, path: str | Path):
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(self.snapshot(), indent=2, allow_nan=False) + "\n")
