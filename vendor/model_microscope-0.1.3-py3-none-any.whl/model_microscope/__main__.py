"""Launch the viewer with ``python -m model_microscope`` from any directory."""

from .server import main

if __name__ == "__main__":
    main()
